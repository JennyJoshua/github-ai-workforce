"""Tests for .github/scripts/zip_inbox.py. Run: python -m unittest discover -s .github/scripts/tests -v"""
import os
import stat
import sys
import tempfile
import unittest
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import zip_inbox as zi  # noqa: E402

NOW = datetime(2026, 10, 11, 12, 0, 0, tzinfo=timezone.utc)


def make_zip(path, files, extra=None):
    """files: {name: bytes|str}; extra: list of ZipInfo,bytes tuples."""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data)
        for info, data in extra or []:
            zf.writestr(info, data)
    return path


def unix_info(name, mode):
    info = zipfile.ZipInfo(name)
    info.create_system = 3
    info.external_attr = mode << 16
    return info


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name) / "repo"
        (self.root / "_inbox").mkdir(parents=True)
        self.inbox = self.root / "_inbox"
        self.failed = self.root / "_failed"

    def put(self, name, files, extra=None):
        return make_zip(self.inbox / name, files, extra)

    def run_inbox(self):
        return zi.process_inbox(self.root, now=NOW)

    def assertRejected(self, name, fragment):
        outcomes = self.run_inbox()
        self.assertEqual(outcomes[0].status, "rejected", outcomes[0])
        self.assertTrue(any(fragment in r for r in outcomes[0].reasons), outcomes[0].reasons)
        self.assertFalse((self.inbox / name).exists())
        self.assertTrue(list(self.failed.glob("*.zip")))
        self.assertTrue(list(self.failed.glob("*.txt")))
        return outcomes[0]


class SuccessTests(Base):
    def test_extracts_into_repo_relative_paths(self):
        self.put("workforce-docs-update.zip", {
            "docs/WORKFLOW.md": "w", "handovers/CLAUDE_HANDOVER.md": "h", "prompts/reviewer.md": "r"})
        out = self.run_inbox()[0]
        self.assertEqual(out.status, "processed")
        self.assertEqual((self.root / "docs/WORKFLOW.md").read_text(), "w")
        self.assertEqual((self.root / "handovers/CLAUDE_HANDOVER.md").read_text(), "h")
        self.assertEqual((self.root / "prompts/reviewer.md").read_text(), "r")
        self.assertFalse((self.root / "output").exists())
        self.assertFalse((self.inbox / "workforce-docs-update.zip").exists())
        self.assertEqual(sorted(out.applied.added), ["docs/WORKFLOW.md", "handovers/CLAUDE_HANDOVER.md", "prompts/reviewer.md"])

    def test_overwrites_existing_and_keeps_others(self):
        (self.root / "docs").mkdir()
        (self.root / "docs/WORKFLOW.md").write_text("old")
        (self.root / "docs/OTHER.md").write_text("keep")
        (self.root / "docs/SAME.md").write_text("same")
        self.put("update.zip", {"docs/WORKFLOW.md": "new", "docs/SAME.md": "same"})
        out = self.run_inbox()[0]
        self.assertEqual((self.root / "docs/WORKFLOW.md").read_text(), "new")
        self.assertEqual((self.root / "docs/OTHER.md").read_text(), "keep")
        self.assertEqual(out.applied.updated, ["docs/WORKFLOW.md"])
        self.assertEqual(out.applied.unchanged, ["docs/SAME.md"])

    def test_allowed_root_file_and_directory_entries(self):
        self.put("root.zip", {"README.md": "r", "docs/": ""})
        # explicit directory entries plus a file
        make_zip(self.inbox / "root.zip", {"README.md": "r", "docs/": "", "docs/a.md": "a"})
        self.assertEqual(self.run_inbox()[0].status, "processed")
        self.assertTrue((self.root / "README.md").exists())

    def test_env_example_allowed(self):
        self.put("cfg.zip", {"config/.env.example": "KEY=changeme"})
        self.assertEqual(self.run_inbox()[0].status, "processed")

    def test_empty_inbox_and_readme_ignored(self):
        (self.inbox / "README.md").write_text("x")
        self.assertEqual(self.run_inbox(), [])


class RejectionTests(Base):
    def test_path_traversal(self):
        self.put("bad.zip", {"docs/ok.md": "x", "../../outside.txt": "x"})
        self.assertRejected("bad.zip", "path traversal")
        self.assertFalse((self.root / "docs/ok.md").exists())
        self.assertFalse((Path(self._tmp.name) / "outside.txt").exists())

    def test_embedded_traversal(self):
        self.put("bad.zip", {"docs/../../x.md": "x"})
        self.assertRejected("bad.zip", "path traversal")

    def test_absolute_and_drive_paths(self):
        self.put("a.zip", {"/etc/passwd": "x"})
        self.assertRejected("a.zip", "absolute path")
        self.put("b.zip", {"C:/Windows/x.txt": "x"})
        self.assertRejected("b.zip", "absolute path")

    def test_backslash(self):
        self.put("bad.zip", {"docs\\x.md": "x"})
        self.assertRejected("bad.zip", "backslash")

    def test_duplicate_paths(self):
        with mock.patch("warnings.warn"):
            self.put("dup.zip", {"docs/a.md": "1"}, extra=[(zipfile.ZipInfo("docs/a.md"), b"2")])
        self.assertRejected("dup.zip", "duplicate")
        self.assertFalse((self.root / "docs/a.md").exists())

    def test_case_insensitive_duplicates(self):
        self.put("dup.zip", {"docs/a.md": "1", "docs/A.md": "2"})
        self.assertRejected("dup.zip", "duplicate")

    def test_file_folder_conflict(self):
        self.put("c.zip", {"docs/a": "1", "docs/a/b.md": "2"})
        self.assertRejected("c.zip", "parent path is also a file")

    def test_symlink(self):
        self.put("s.zip", {"docs/ok.md": "x"}, extra=[(unix_info("docs/link.md", stat.S_IFLNK | 0o777), b"/etc/passwd")])
        self.assertRejected("s.zip", "symbolic link")
        self.assertFalse((self.root / "docs/ok.md").exists())

    def test_special_file(self):
        self.put("s.zip", {}, extra=[(unix_info("docs/pipe", stat.S_IFIFO | 0o644), b"")])
        self.assertRejected("s.zip", "special file")

    def test_encrypted_flag(self):
        zp = self.put("e.zip", {"docs/enc.md": "x"})
        raw = bytearray(zp.read_bytes())
        raw[raw.index(b"PK\x03\x04") + 6] |= 0x01  # local header flags
        raw[raw.index(b"PK\x01\x02") + 8] |= 0x01  # central directory flags
        zp.write_bytes(bytes(raw))
        self.assertRejected("e.zip", "encrypted")

    def test_oversized_zip(self):
        self.put("big.zip", {"docs/a.md": "x" * 5000})
        with mock.patch.object(zi, "MAX_ZIP_BYTES", 100):
            self.assertRejected("big.zip", "larger than")

    def test_too_many_entries(self):
        self.put("many.zip", {f"docs/{i}.md": "x" for i in range(5)})
        with mock.patch.object(zi, "MAX_ENTRIES", 3):
            self.assertRejected("many.zip", "more than 3 entries")

    def test_declared_uncompressed_limit(self):
        self.put("zip-bomb.zip", {"docs/a.md": "0" * 100000})
        with mock.patch.object(zi, "MAX_TOTAL_UNCOMPRESSED", 1000):
            self.assertRejected("zip-bomb.zip", "total uncompressed size")

    def test_actual_uncompressed_limit_during_streaming(self):
        zp = self.put("stream.zip", {"docs/a.md": "0" * 100000})
        entries = zi.validate_archive(zp)
        with mock.patch.object(zi, "MAX_TOTAL_UNCOMPRESSED", 1000), tempfile.TemporaryDirectory() as st:
            with self.assertRaises(zi.ZipRejected):
                zi.extract_to_staging(zp, entries, Path(st))

    def test_secret_file_names(self):
        for i, name in enumerate([".env", "config/.env.production", "config/server.pem",
                                  "config/id_rsa", "docs/my-secrets.md", "config/credentials.json",
                                  "config/.ssh/config"]):
            with self.subTest(name=name):
                self.put(f"s{i}.zip", {name: "x"})
        outcomes = self.run_inbox()
        self.assertTrue(all(o.status == "rejected" for o in outcomes), outcomes)
        self.assertEqual(len(outcomes), 7)

    def test_secret_content_rejected_and_not_leaked(self):
        token = "ghp_" + "A1b2C3d4" * 5
        self.put("leak.zip", {"docs/notes.md": f"token {token}"})
        out = self.assertRejected("leak.zip", "GitHub token")
        report = next(self.failed.glob("*.txt")).read_text()
        self.assertNotIn(token, report)
        self.assertNotIn(token, " ".join(out.reasons))

    def test_private_key_content(self):
        self.put("k.zip", {"docs/x.md": "-----BEGIN RSA PRIVATE KEY-----\nabc"})
        self.assertRejected("k.zip", "private key block")

    def test_forbidden_folders(self):
        cases = {"g1.zip": ".github/workflows/process-zip.yml", "g2.zip": ".git/config",
                 "g3.zip": "docs/node_modules/x.js", "g4.zip": "src/.venv/x.py",
                 "g5.zip": "src/__pycache__/x.pyc", "g6.zip": "docs/build/out.html",
                 "g7.zip": ".github/scripts/zip_inbox.py"}
        for n, p in cases.items():
            self.put(n, {p: "x"})
        outcomes = self.run_inbox()
        self.assertTrue(all(o.status == "rejected" for o in outcomes))
        self.assertFalse((self.root / ".github").exists())

    def test_unlisted_top_level_and_root_files(self):
        self.put("t1.zip", {"output/x.md": "x"})
        self.put("t2.zip", {"package.json": "{}"})
        self.put("t3.zip", {"_inbox/evil.zip": "x"})
        self.put("t4.zip", {"_failed/x.txt": "x"})
        outcomes = self.run_inbox()
        self.assertTrue(all(o.status == "rejected" for o in outcomes))

    def test_unsafe_characters(self):
        self.put("u.zip", {"docs/a b.md": "x"})
        self.assertRejected("u.zip", "unsupported characters")

    def test_corrupted_and_non_zip(self):
        (self.inbox / "garbage.zip").write_bytes(b"this is not a zip")
        self.assertRejected("garbage.zip", "not a valid")

    def test_crc_corruption_leaves_repo_untouched(self):
        zp = self.inbox / "crc.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_STORED) as zf:
            zf.writestr("docs/a.md", "good-one")
            zf.writestr("docs/b.md", "payload-to-corrupt")
        raw = bytearray(zp.read_bytes())
        i = raw.index(b"payload-to-corrupt")
        raw[i] ^= 0xFF
        zp.write_bytes(bytes(raw))
        self.assertRejected("crc.zip", "corrupted")
        self.assertFalse((self.root / "docs").exists())

    def test_one_bad_entry_blocks_whole_archive(self):
        self.put("mixed.zip", {"docs/good.md": "x", "docs/also-good.md": "y", "package.json": "{}"})
        self.assertRejected("mixed.zip", "package.json")
        self.assertFalse((self.root / "docs").exists())

    def test_bad_zip_name(self):
        make_zip(self.inbox / "Bad Name.zip", {"docs/a.md": "x"})
        self.assertRejected("Bad Name.zip", "lowercase")

    def test_inbox_symlink_rejected_without_following(self):
        target = Path(self._tmp.name) / "real.zip"
        make_zip(target, {"docs/a.md": "x"})
        os.symlink(target, self.inbox / "link.zip")
        outcome = self.run_inbox()[0]
        self.assertEqual(outcome.status, "rejected")
        self.assertFalse((self.root / "docs").exists())
        self.assertTrue(target.exists())


class ApplySafetyTests(Base):
    def test_existing_folder_at_target_rejected(self):
        (self.root / "docs/a.md").mkdir(parents=True)
        self.put("x.zip", {"docs/a.md": "x"})
        self.assertRejected("x.zip", "existing target is a folder")

    def test_symlinked_parent_rejected(self):
        outside = Path(self._tmp.name) / "outside"
        outside.mkdir()
        os.symlink(outside, self.root / "docs")
        self.put("x.zip", {"docs/a.md": "x"})
        self.assertRejected("x.zip", "symbolic link")
        self.assertEqual(list(outside.iterdir()), [])

    def test_rollback_on_unexpected_error(self):
        (self.root / "docs").mkdir()
        (self.root / "docs/a.md").write_text("original")
        self.put("r.zip", {"docs/a.md": "changed", "docs/new/b.md": "b", "docs/z.md": "z"})
        real_replace = os.replace
        calls = {"n": 0}

        def flaky(src, dst):
            calls["n"] += 1
            if calls["n"] == 3:
                raise OSError("disk full")
            return real_replace(src, dst)

        with mock.patch("os.replace", flaky):
            with self.assertRaises(OSError):
                self.run_inbox()
        self.assertEqual((self.root / "docs/a.md").read_text(), "original")
        self.assertFalse((self.root / "docs/new").exists())
        self.assertFalse(list(self.root.rglob(".zipinbox-*")))
        self.assertTrue((self.inbox / "r.zip").exists())  # left for a retry


class FailureReportTests(Base):
    def test_unique_failure_names_never_overwrite(self):
        for _ in range(3):
            (self.inbox / "same.zip").write_bytes(b"junk")
            self.run_inbox()
        self.assertEqual(len(list(self.failed.glob("*.zip"))), 3)
        self.assertEqual(len(list(self.failed.glob("*.txt"))), 3)

    def test_report_contents(self):
        self.put("bad.zip", {"package.json": "{}"})
        self.run_inbox()
        text = next(self.failed.glob("*.txt")).read_text()
        self.assertIn("ZIP REJECTED", text)
        self.assertIn("package.json", text)
        self.assertIn("SHA-256", text)
        self.assertIn("20261011T120000Z-bad", next(self.failed.glob("*.txt")).name)

    def test_log_safe_rendering(self):
        self.assertEqual(zi.printable("a\nb\x00é"), "a\\nb\\x00\\xe9")
        self.assertLessEqual(len(zi.printable("x" * 500)), 120)


class ConfigTests(unittest.TestCase):
    def test_limits_match_requirements(self):
        self.assertEqual(zi.MAX_ZIP_BYTES, 50 * 1024 * 1024)
        self.assertEqual(zi.MAX_ENTRIES, 1000)
        self.assertEqual(zi.MAX_TOTAL_UNCOMPRESSED, 100 * 1024 * 1024)

    def test_github_dir_never_allowed(self):
        self.assertNotIn(".github", zi.ALLOWED_DIRS)
        self.assertIn(".github", zi.FORBIDDEN_COMPONENTS)


if __name__ == "__main__":
    unittest.main()
